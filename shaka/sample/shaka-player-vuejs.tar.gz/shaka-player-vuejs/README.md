# shaka-player-vuejs
This simple project contains basic implementation of shaka player with Nuxt.js.

A running example can be found at [https://davidjamesherzog.github.io/shaka-player-vuejs/](https://davidjamesherzog.github.io/shaka-player-vuejs/).

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your unit tests
```
npm run test:unit
```

### Lints and fixes files
```
npm run lint
```
